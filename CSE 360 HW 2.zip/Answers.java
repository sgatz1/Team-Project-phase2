import java.util.ArrayList;
import java.util.List;

public class Answers 
{
    private List<Answer> answerList;
    private List<Answer> answerSubset;
    
    public Answers() {
        answerList = new ArrayList<>();
        answerSubset = new ArrayList<>();
    }
    

    public String addAnswer(Answer a) {
        if (a == null) 
        {
        	return "Answer is null";
        }
        if (searchID(a.getID()) == null) 
        {
        	answerList.add(a);
            return "Answer added";
        }
        
    	return "Error Answer already exists";
    }
    
    
    public String updateAnswer(int id, Answer a)
    {
    	if(a == null)
    	{
    		return "Error Answer Question";
    	}
    	
    	Answer oldAnswer = searchID(id);
    	
    	if(oldAnswer  == null)
    	{
    		return "Error Null ID";
    	}
    	
    	int answerindex = answerList.indexOf(oldAnswer);
    	answerList.set(answerindex, a);
    	return "Answer updated";
    	
    	
    }

    public Answer searchID(int id)
    {
    	for(Answer temp : answerList)
    	{
    		if(temp.getID() == id)
    		{
    			return temp;
    		}		
    	}
    	return null;
    }
    
    public List<Answer> getQuestionAnswers(int questionId) 
    {
        List<Answer> questionAnswers = new ArrayList<>();
        for (Answer a : answerList) 
        {
            if(a.getQuestionID() == questionId)
            {
            	questionAnswers.add(a);
            }
        }
        return questionAnswers;
    }  

    public String deleteAnswer(int id)
    {
    	
    	Answer temp = searchID(id);
    	if(temp != null)
    	{
    		answerList.remove(temp);
    		return "Answer deleted";
    	}

    	return "Error Answer not deleted";
    }
    
    public List<Answer> search(String searchTerm) 
    {
    	answerSubset.clear();
        if (searchTerm == null || searchTerm.trim().isEmpty()) 
        {
        	answerSubset.addAll(answerList);
        }
        else 
        {
        	 String search = searchTerm.toLowerCase();
             for (Answer a : answerList) 
             {
                 if (a.getdecription().toLowerCase().contains(search))
                 {
                 	answerSubset.add(a);
                 }	
             }
        }
           
           
        return new ArrayList<>(answerSubset);
    }


    public List<Answer> getAnswerList()
    {
    	return new ArrayList<>(answerList);
    }

    public List<Answer> getSubset()
    {
    	return new ArrayList<>(answerSubset);
    }

}