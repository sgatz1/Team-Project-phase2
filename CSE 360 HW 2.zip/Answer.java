
public class Answer 
{
	String decription;
	int answerID;
	int answerScore;
	int questionID;
	//Constructor
	public Answer(String answerText, int aid, int qid)
	{
		decription = answerText;
		answerID = aid;
		answerScore = 0;
		questionID = qid;
		
	}
	//getters and setters
	public String getdecription()
	{
		return decription;
	}
	
	public int getID()
	{
		return answerID;
	}
	public int getQuestionID()
	{
		return answerID;
	}
	public int getScore()
	{
		return answerScore;
	}
	
	public void setdecription(String newdecription)
	{
		decription = newdecription;
	}
	
	public void setID(int newID)
	{
		answerID = newID;
	}
	
	public void setQuestionID(int newID)
	{
		questionID = newID;
	}
	
	public void upvote()
	{
		answerScore = answerScore + 1;
	}
	
	public void downvote()
	{
		answerScore = answerScore - 1;
	}
	
	
	
}
