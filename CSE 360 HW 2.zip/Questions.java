
import java.util.ArrayList;
import java.util.List;

public class Questions
{
	private List<Question> questionList;
	private List<Question> questionSubset;
	
	public Questions()
	{
		questionList = new ArrayList<>();
		questionSubset = new ArrayList<>();
	}
	
	public String newQuestion(Question q)
	{
		if(q == null)
		{
			return "Error Null Question";
		}
		if(searchID(q.getID()) == null)
		{
			questionList.add(q);
			return "Question added";
		}

			return "Error Question already exists";
	}

public String updateQuestion(int id, Question q)
{
	if(q == null)
	{
		return "Error Null Question";
	}
	
	Question oldQuestion = searchID(id);
	
	if(oldQuestion  == null)
	{
		return "Error Null ID";
	}
	
	int questionindex = questionList.indexOf(oldQuestion);
	questionList.set(questionindex, q);
	return "Question updated";
	
	
}

public Question searchID(int id)
{
	for(Question temp : questionList)
	{
		if(temp.getID() == id)
		{
			return temp;
		}		
	}
	return null;
}

public String deleteQuestion(int id)
{
	
	Question temp = searchID(id);
	if(temp != null)
	{
		questionList.remove(temp);
		return "Question deleted";
	}

	return "Error Question not deleted";
}


public List<Question> search(String searchTerm) 
{
	questionSubset.clear();
    if (searchTerm == null || searchTerm.trim().isEmpty()) 
    {
    	questionSubset.addAll(questionList);
    }
    else 
    {
    	 String search = searchTerm.toLowerCase();
         for (Question q : questionList) 
         {
             if (q.getdecription().toLowerCase().contains(search))
             {
             	questionSubset.add(q);
             }	
         }
    }
       
       
    return new ArrayList<>(questionSubset);
}


public List<Question> getQuestionList()
{
	return new ArrayList<>(questionList);
}

public List<Question> getSubset()
{
	return new ArrayList<>(questionSubset);
}

}











	

