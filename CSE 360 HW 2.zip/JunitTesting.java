
import static org.junit.Assert.*;

import org.junit.Test;

public class JunitTesting {
	
	Question q1 = new Question("Is there supposed to be a link for these or are they from the book? I am unable to find the files in our course.", 1);
	Question q2 = new Question("Hello guys, I noticed that I am missing a file named JavaFX SDK in my build path and I may have deleted it. Any suggestions on how I can have it back?", 2);
	Question q3;
	
	 Answer a1 = new Answer("For those who did not see the comment clarifying this, you can find the articles to read further down in the module, labelled \"Reading Assignment.\" I will make an announcement about the textbook on Canvas.", 1, 1);
	 Answer a2 = new Answer("Follow this tutorial- https://canvas.asu.edu/courses/236306/files/113231786?module_item_id=17565852", 2, 2);
	 Answer a3 = new Answer("I would recommend renaming your file so that you can Identify the old and then redownload the full file from the videos. This way if you have new code, you can move it over without losing it, but you want to start on a good foot.", 3, 2);
	 Answer a4;
	 
	Questions questions = new Questions();
	Answers answers = new Answers();
		

	  @Test
	  //A valid question will be added
	    public void testQuestion1() {
	     String validQuestion = questions.newQuestion(q1);
	        assertTrue("Question is valid", validQuestion.contains("Question added"));
	    }
	    
	  
  
	  @Test
	//Testing using a invalid question
	    public void testInvalidQuestion() {
		  String invalidQuestion = questions.newQuestion(q3);
	        assertFalse("Username is invalid", invalidQuestion.contains("Question added"));
	    }
	  
	  @Test
		//Testing using a valid question
		    public void testAnswer1() {
		        String validAnswer = answers.addAnswer(a1);
		        assertTrue("Answer is valid", validAnswer.contains("Answer added"));
		    }
		  
	  
	  @Test
		//Testing using a invalid question
		    public void testInvalidAnswer() {
			  String invalidAnswer = answers.addAnswer(a4);
		        assertFalse("Answer is invalid", invalidAnswer.contains("Answer added"));
		    }
	  
	  //Testing updating a valid question
	  public void testUpdate1() {
		  String validUpdate = questions.updateQuestion(1, q2);
		  assertTrue("Question is updated", validUpdate.contains("Question updated"));
	  }
	  
	  //Testing updating a invalid question
	  public void testUpdate2() {
		  String validUpdate = questions.updateQuestion(1, q3);
		  assertFalse("Question is updated", validUpdate.contains("Question updated"));
	  }
	  
	  //Testing updating a valid answer
	  public void testUpdate3() {
		  String validUpdate = answers.updateAnswer(1, a2);
		  assertTrue("Answer is updated", validUpdate.contains("Answer updated"));
	  }
	  
	  //Testing updating a invalid answer
	  public void testUpdate4() {
		  String validUpdate = answers.updateAnswer(1, a4);
		  assertFalse("Answer is updated", validUpdate.contains("Answer updated"));
	  }
	 
	  //Testing deleting a valid question
	  public void testDelete1() {
		  String valid = questions.deleteQuestion(1);
		  assertTrue("Question is deleted", valid.contains("Question deleted"));
	  }
	  
	  //Testing deleting a invalid question
	  public void testDelete2() {
		  String invalid = questions.deleteQuestion(4);
		  assertFalse("Question is deleted", invalid.contains("Question deleted"));
	  }
	  
	  //Testing deleting a valid answer
	  public void testDelete3() {
		  String valid = answers.deleteAnswer(1);
		  assertTrue("Answer is deleted", valid.contains("Answer deleted"));
	  }
	  
	  //Testing deleting a invalid answer
	  public void testDelete4() {
		  String invalid = answers.deleteAnswer(4);
		  assertFalse("Answer is deleted", invalid.contains("Answer deleted"));
	  }
	  
	  
	  
	  

}
