
public class Test {

	public static void main(String[] args) {
		
		//Creating questions and answers
		Question q1 = new Question("Is there supposed to be a link for these or are they from the book? I am unable to find the files in our course.", 1);
		Question q2 = new Question("Hello guys, I noticed that I am missing a file named JavaFX SDK in my build path and I may have deleted it. Any suggestions on how I can have it back?", 2);

	
		 Answer a1 = new Answer("For those who did not see the comment clarifying this, you can find the articles to read further down in the module, labelled \"Reading Assignment.\" I will make an announcement about the textbook on Canvas.", 1, 1);
		 Answer a2 = new Answer("Follow this tutorial- https://canvas.asu.edu/courses/236306/files/113231786?module_item_id=17565852", 2, 2);
		 Answer a3 = new Answer("I would recommend renaming your file so that you can Identify the old and then redownload the full file from the videos. This way if you have new code, you can move it over without losing it, but you want to start on a good foot.", 3, 2);
		 
		 //Showing the information in each question and answer
		System.out.println("Question is " + q1.getdecription());
		System.out.println("Question id is " + q1.getID());
		
		System.out.println("Question is " + q2.getdecription());
		System.out.println("Question id is " + q2.getID());
		
		System.out.println("Answer is " + a1.getdecription());
		System.out.println("Answer id is " + a1.getID());
		System.out.println("Answer question id is " + a1.getID());
		
		System.out.println("Answer is " + a2.getdecription());
		System.out.println("Answer id is " + a2.getID());
		System.out.println("Answer question id is" + a2.getID());
		
		
		System.out.println("Answer is " + a3.getdecription());
		System.out.println("Answer id is " + a3.getID());
		System.out.println("Answer question id is " + a3.getID());

		
		Questions questions = new Questions();
		Answers answers = new Answers();
		
		// adding questions and answers to each type of list
		
		questions.newQuestion(q1);
		questions.newQuestion(q2);
		
		answers.addAnswer(a1);
		answers.addAnswer(a2);
		answers.addAnswer(a3);
		
		//Testing functions of the answers class and questions class
		questions.search("link");
		
		System.out.println("Subset is " + questions.getSubset());
		
		answers.search("who");
		System.out.println("Subset is " + answers.getSubset());
		
		
		questions.deleteQuestion(2);
		q2.setID(-1);
		System.out.println("Question Id is now" + q2.getID());
		
		q2.setID(2);
		
		q2.setdecription("Are we writing this PasswordRecognizer.java from scratch? Can we use the code in the PasswordEvaluator?");
		
		System.out.println("Question " + q2.getID() + " is now " + q2.getdecription());
		
		
		answers.deleteAnswer(2);
		answers.deleteAnswer(3);
		
		a2.setID(-1);
		System.out.println("Answer Id is now" + a2.getID());
		a2.setID(2);
		a2.setdecription("No, you don’t start from scratch. Copy the provided PasswordEvaluator into HW1 and modify it.");
		System.out.println("Answer " + a2.getID() + " is now " + a2.getdecription());
		
	
		
	}

}
