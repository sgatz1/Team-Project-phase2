
public class Question {
	String decription;
	int questionID;
	
	//Constructor
	public Question(String questiontext, int id)
	{
		decription = questiontext;
		questionID = id;
		
	}
	//getters and setters
	public String getdecription()
	{
		return decription;
	}
	
	public int getID()
	{
		return questionID;
	}
	
	public void setdecription(String newdecription)
	{
		decription = newdecription;
	}
	
	public void setID(int newID)
	{
		questionID = newID;
	}
	
	
	
	
	

}
